/** Automatically generated file. DO NOT MODIFY */
package edu.pdx.cs410.wifi.direct.file.transfer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}