/** Automatically generated file. DO NOT MODIFY */
package com.example.android.wifidirect;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}